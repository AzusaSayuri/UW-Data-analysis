function [MetDataWY,PptDataWY,ValDataWY,Nt]=SelectInputs(MetData,PptData,ValData,WY)

iWY=any(ones(length(MetData.t),1)*WY==MetData.WY*ones(1,length(WY)),2);
MetDataWY = SelectData(MetData,iWY);
PptDataWY = SelectData(PptData,iWY);
ValDataWY = SelectData(ValData,iWY);
Nt=length(MetDataWY.t);

return